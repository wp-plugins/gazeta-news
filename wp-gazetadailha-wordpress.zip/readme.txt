=== Plugin Name ===
Contributors: erick.pessoa
Donate link: http://example.com/
Tags: noticias, sao luis, gazerta
Requires at least: 3.0.1
Tested up to: 3.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Este widget lhe permite manter seu site sempre atualizado com as principais noticias do Portal Gazeta da Ilha

== Description ==

Plugin desenvolvido por WEBSISTI Soluções Inteligentes, a pedido do Jornal Gazeta da Ilha, para ser um instrumento 
através do qual todo e qualquer usuário interessado e que utilize WordPress, tenha a possibilidade de incorporar as 
notícias publicadas pela Gazeta da Ilha em seu site.

== Installation ==

Esta seção descrive como você pode instalar o plugin.

e.g.

1. Faça a instalação através do WordPress;
2. No menu Aparência > Widget acrescente Gazeta News no sidebar desejado;


== Screenshots ==

1. Assim é o plugin em execução: '/assets/screenshot-1.png'

== Changelog ==

= 0.2 =
* Ajustes para melhorar a identificação do plugin.

= 0.1 =
* Publicação

== Upgrade Notice ==

= 0.1 =
Publicação

`<?php code(); // goes in backticks ?>`